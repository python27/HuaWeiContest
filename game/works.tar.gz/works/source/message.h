#ifndef MESSAGE_H_
#define MESSAGE_H_

int ProcessReceivedMsg(char buffer[1024]);
#endif//

#ifndef MESSAGE_H_
#define MESSAGE_H_

void ProcessReceivedMsg(char buffer[512]);
#endif//
